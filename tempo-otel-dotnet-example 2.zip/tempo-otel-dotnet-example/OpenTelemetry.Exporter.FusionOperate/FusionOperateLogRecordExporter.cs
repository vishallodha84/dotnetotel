using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using OpenTelemetry.Logs;

namespace OpenTelemetry.Exporter.FusionOperate
{
    public class FusionOperateLogRecordExporter : BaseExporter<LogRecord>
    {
        private readonly JsonSerializerOptions serializerOptions;
        private readonly FusionOperateExporterOptions options;
        
        public FusionOperateLogRecordExporter(FusionOperateExporterOptions options)
        {
            this.options = options ?? new FusionOperateExporterOptions();

            this.serializerOptions = new JsonSerializerOptions()
            {
                WriteIndented = true,
                IgnoreNullValues = true,
            };

            this.serializerOptions.Converters.Add(new JsonStringEnumConverter());
            this.serializerOptions.Converters.Add(new ActivitySpanIdConverter());
            this.serializerOptions.Converters.Add(new ActivityTraceIdConverter());
        }

        public override ExportResult Export(in Batch<LogRecord> batch)
        {
            try
            {
                using var scope = SuppressInstrumentationScope.Begin();

                using var stream = new MemoryStream();
                using (var writer = new Utf8JsonWriter(stream, new JsonWriterOptions()
                {
                    Indented = true
                }))
                {
                    writer.WriteStartArray();

                    foreach (var logRecord in batch)
                    {
                        var foLog = logRecord.ToFusionOperateLog(this.ParentProvider.GetResource());
                        foLog.Write(writer);
                    }

                    writer.WriteEndArray();
                }

                string json = Encoding.UTF8.GetString(stream.ToArray());

                System.Console.WriteLine("FO LOG JSON ---------------");
                System.Console.WriteLine($"{this.options.Name} :: {json}");
                System.Console.WriteLine(" ------------------------------");

                /*
                System.Diagnostics.Trace.WriteLine("FO LOG JSON ---------------");
                System.Diagnostics.Trace.WriteLine($"{this.options.Name} :: {json}");
                System.Diagnostics.Trace.WriteLine(" ------------------------------");
                */
                // Default LogRecord to JSON
                //foreach (var logRecord in batch)
                //{
                //    System.Diagnostics.Trace.WriteLine("LogRecord JSON ---------------");
                //    System.Diagnostics.Trace.WriteLine(JsonSerializer.Serialize(logRecord, this.serializerOptions));
                //    System.Diagnostics.Trace.WriteLine(" ------------------------------");
                //}
            }
            catch
            {
                return ExportResult.Failure;
            }

            return ExportResult.Success;
        }
    }
}
