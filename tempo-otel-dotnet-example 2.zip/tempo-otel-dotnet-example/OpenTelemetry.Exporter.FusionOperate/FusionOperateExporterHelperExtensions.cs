using System;
using Microsoft.Extensions.Options;
using OpenTelemetry.Logs;
using OpenTelemetry.Trace;

namespace OpenTelemetry.Exporter.FusionOperate
{
    public static class FusionOperateExporterHelperExtensions
    {
        public static OpenTelemetryLoggerOptions AddFusionOperateExporter(this OpenTelemetryLoggerOptions loggerOptions, Action<FusionOperateExporterOptions> configure = null)
        {
            Console.WriteLine("Inside FusionOperateExporterHelperExtensions-");
            Console.WriteLine(loggerOptions);
            if (loggerOptions == null)
            {
                Console.WriteLine("11111111");
                throw new ArgumentNullException(nameof(loggerOptions));
            }

            var options = new FusionOperateExporterOptions();
            configure?.Invoke(options);

            var exporter = new FusionOperateLogRecordExporter(options);

            Console.WriteLine(options.LogExportProcessorType);
            Console.WriteLine(exporter);
            if (options.LogExportProcessorType == ExportProcessorType.Simple)
            {
                Console.WriteLine("222222");
                return loggerOptions.AddProcessor(new SimpleLogRecordExportProcessor(exporter));
            }
            else
            {
                Console.WriteLine("33333");
                return loggerOptions.AddProcessor(new BatchLogRecordExportProcessor(
                    exporter,
                    options.LogBatchExportProcessorOptions.MaxQueueSize,
                    options.LogBatchExportProcessorOptions.ScheduledDelayMilliseconds,
                    options.LogBatchExportProcessorOptions.ExporterTimeoutMilliseconds,
                    options.LogBatchExportProcessorOptions.MaxExportBatchSize));
            }
        }

        public static TracerProviderBuilder AddFusionOperateExporter(this TracerProviderBuilder builder, Action<FusionOperateExporterOptions> configure = null)
        {
            if (builder == null)
            {
                Console.WriteLine("Builder null in AddFusionOperateExporter");
                throw new ArgumentNullException(nameof(builder));
            }

            if (builder is IDeferredTracerProviderBuilder deferredTracerProviderBuilder)
            {
                return deferredTracerProviderBuilder.Configure((serviceProvider, builder) =>
                {
                    Console.WriteLine("Builder null in AddFusionOperateExporter 1111");
                    var options = (IOptions<FusionOperateExporterOptions>)serviceProvider.GetService(typeof(IOptions<FusionOperateExporterOptions>));
                    Console.WriteLine("Options------",options);
                    AddFusionOperateExporter(builder, options?.Value ?? new FusionOperateExporterOptions(), configure);
                });
            }

            return AddFusionOperateExporter(builder, new FusionOperateExporterOptions(), configure);
        }

        private static TracerProviderBuilder AddFusionOperateExporter(TracerProviderBuilder builder, FusionOperateExporterOptions options, Action<FusionOperateExporterOptions> configure = null)
        {
            Console.WriteLine("called AddFusionOperateExporter");
            configure?.Invoke(options);

            var exporter = new FusionOperateActivityExporter(options);
            Console.WriteLine(exporter);
            if (options.ActivityExportProcessorType == ExportProcessorType.Simple)
            {
                return builder.AddProcessor(new SimpleActivityExportProcessor(exporter));
            }
            else
            {
                return builder.AddProcessor(new BatchActivityExportProcessor(
                    exporter,
                    options.ActivityBatchExportProcessorOptions.MaxQueueSize,
                    options.ActivityBatchExportProcessorOptions.ScheduledDelayMilliseconds,
                    options.ActivityBatchExportProcessorOptions.ExporterTimeoutMilliseconds,
                    options.ActivityBatchExportProcessorOptions.MaxExportBatchSize));
            }
        }
    }
}
