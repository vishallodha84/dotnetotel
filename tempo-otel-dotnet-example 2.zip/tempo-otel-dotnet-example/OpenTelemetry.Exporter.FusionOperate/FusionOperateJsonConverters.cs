using System;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OpenTelemetry.Exporter.FusionOperate
{
    internal class ActivityTraceIdConverter : JsonConverter<ActivityTraceId>
    {
        public override ActivityTraceId Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            throw new NotImplementedException();
        }

        public override void Write(Utf8JsonWriter writer, ActivityTraceId value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToHexString());
        }
    }

    internal class ActivitySpanIdConverter : JsonConverter<ActivitySpanId>
    {
        public override ActivitySpanId Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            throw new NotImplementedException();
        }

        public override void Write(Utf8JsonWriter writer, ActivitySpanId value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToHexString());
        }
    }
}
