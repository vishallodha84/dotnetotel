using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace OpenTelemetry.Exporter.FusionOperate
{
    internal static class FusionOperateJsonHelper
    {
        public static readonly JsonEncodedText TimestampPropertyName = JsonEncodedText.Encode("timestamp");

        public static readonly JsonEncodedText TraceIdPropertyName = JsonEncodedText.Encode("traceId");

        public static readonly JsonEncodedText SpanIdPropertyName = JsonEncodedText.Encode("spanId");

        public static readonly JsonEncodedText TraceFlagsPropertyName = JsonEncodedText.Encode("traceFlags");

        public static readonly JsonEncodedText SeverityTextPropertyName = JsonEncodedText.Encode("severityText");

        public static readonly JsonEncodedText SeverityNumberPropertyName = JsonEncodedText.Encode("severityNumber");

        public static readonly JsonEncodedText NamePropertyName = JsonEncodedText.Encode("name");

        public static readonly JsonEncodedText BodyPropertyName = JsonEncodedText.Encode("body");

        public static readonly JsonEncodedText ResourcePropertyName = JsonEncodedText.Encode("resource");

        public static readonly JsonEncodedText AttributesPropertyName = JsonEncodedText.Encode("attributes");
    }
}
