using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace OpenTelemetry.Exporter.FusionOperate
{
    internal readonly struct FusionOperateLog
    {
        public FusionOperateLog(
            long? timestamp,
            string traceId,
            string spanId,
            byte? flags,
            string severityText,
            byte? severityNumber,
            string name,
            string body,
            IEnumerable<KeyValuePair<string, string>> resource,
            IEnumerable<KeyValuePair<string, string>> attributes
            )
        {
            this.Timestamp = timestamp;
            this.TraceId = traceId;
            this.SpanId = spanId;
            this.TraceFlags = flags;
            this.SeverityText = severityText;
            this.SeverityNumber = severityNumber;
            this.Name = name;
            this.Body = body;
            this.Resource = resource;
            this.Attributes = attributes;
        }

        public long? Timestamp { get; }

        public string TraceId { get; }

        public string SpanId { get; }
               
        public byte? TraceFlags { get; }
        
        public string SeverityText { get; }

        public byte? SeverityNumber { get; }

        public string Name { get; }

        public string Body { get; }

        public IEnumerable<KeyValuePair<string, string>> Resource { get; }
        
        public IEnumerable<KeyValuePair<string, string>> Attributes { get; }

        public void Write(Utf8JsonWriter writer)
        {
            writer.WriteStartObject();

            if (this.Timestamp.HasValue)
            {
                writer.WriteNumber(FusionOperateJsonHelper.TimestampPropertyName, this.Timestamp.Value);
            }

            writer.WriteString(FusionOperateJsonHelper.TraceIdPropertyName, this.TraceId);

            writer.WriteString(FusionOperateJsonHelper.SpanIdPropertyName, this.SpanId);

            if (this.TraceFlags.HasValue)
            {
                writer.WriteNumber(FusionOperateJsonHelper.TraceFlagsPropertyName, this.TraceFlags.Value);
            }

            if (this.SeverityText != null)
            {
                writer.WriteString(FusionOperateJsonHelper.SeverityTextPropertyName, this.SeverityText);
            }

            if (this.SeverityNumber.HasValue)
            {
                writer.WriteNumber(FusionOperateJsonHelper.SeverityNumberPropertyName, this.SeverityNumber.Value);
            }

            if (this.Name != null)
            {
                writer.WriteString(FusionOperateJsonHelper.NamePropertyName, this.Name);
            }

            if (this.Body != null)
            {
                writer.WriteString(FusionOperateJsonHelper.BodyPropertyName, this.Body);
            }

            if (this.Resource != null && this.Resource.Any())
            {
                writer.WritePropertyName(FusionOperateJsonHelper.ResourcePropertyName);
                writer.WriteStartObject();

                foreach (var resource in this.Resource)
                {
                    writer.WriteString(resource.Key, resource.Value);
                }

                writer.WriteEndObject();
            }

            if (this.Attributes != null && this.Attributes.Any())
            {
                writer.WritePropertyName(FusionOperateJsonHelper.AttributesPropertyName);
                writer.WriteStartObject();

                foreach (var attribute in this.Attributes)
                {
                    writer.WriteString(attribute.Key, attribute.Value);
                }

                writer.WriteEndObject();
            }

            writer.WriteEndObject();
        }
    }
}
