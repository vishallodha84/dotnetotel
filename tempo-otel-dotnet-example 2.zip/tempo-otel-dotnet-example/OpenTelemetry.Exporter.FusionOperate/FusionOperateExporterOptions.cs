using System;
using System.Diagnostics;
using OpenTelemetry.Logs;

namespace OpenTelemetry.Exporter.FusionOperate
{
    public class FusionOperateExporterOptions
    {
        internal const int DefaultMaxPayloadSizeInBytes = 4096;

        public string Name { get; set; } = "FusionOperateExporter";

        public Uri TraceEndpoint { get; set; } = new Uri("http://localhost:2021/api/v1/traces");

        public Uri LogEndpoint { get; set; } = new Uri("http://localhost:2021/api/v1/logs");

        public int? MaxPayloadSizeInBytes { get; set; } = DefaultMaxPayloadSizeInBytes;

        public ExportProcessorType ActivityExportProcessorType { get; set; } = ExportProcessorType.Batch;
        public BatchExportProcessorOptions<Activity> ActivityBatchExportProcessorOptions { get; set; } = new BatchExportProcessorOptions<Activity>();

        public ExportProcessorType LogExportProcessorType { get; set; } = ExportProcessorType.Batch;

        public BatchExportProcessorOptions<LogRecord> LogBatchExportProcessorOptions { get; set; } = new BatchExportProcessorOptions<LogRecord>();
    }
}
