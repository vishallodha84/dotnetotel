using System;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using OpenTelemetry.Resources;

namespace OpenTelemetry.Exporter.FusionOperate
{
    public class FusionOperateActivityExporter : BaseExporter<Activity>
    {
        private readonly JsonSerializerOptions serializerOptions;
        private readonly FusionOperateExporterOptions options;

        public FusionOperateActivityExporter(FusionOperateExporterOptions options)
        {
            this.options = options ?? new FusionOperateExporterOptions();

            this.serializerOptions = new JsonSerializerOptions()
            {
                WriteIndented = true,
                IgnoreNullValues = true,
            };

            this.serializerOptions.Converters.Add(new JsonStringEnumConverter());
            this.serializerOptions.Converters.Add(new ActivitySpanIdConverter());
            this.serializerOptions.Converters.Add(new ActivityTraceIdConverter());
        }

        public override ExportResult Export(in Batch<Activity> batch)
        {
            using var scope = SuppressInstrumentationScope.Begin();

            foreach (var activity in batch)
            {
                System.Console.WriteLine("FO Activity JSON ---------------");
                System.Console.WriteLine(JsonSerializer.Serialize(activity, this.serializerOptions));
                System.Console.WriteLine(" ------------------------------");
            }

            return ExportResult.Success;
        }
    }
}
