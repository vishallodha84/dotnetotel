using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using OpenTelemetry.Logs;
using OpenTelemetry.Resources;

namespace OpenTelemetry.Exporter.FusionOperate
{
    internal static class FusionOperateConversionExtensions
    {
        private const long NanosecondsPerTicks = 100;
        private const long UnixEpochTicks = 621355968000000000; // = DateTimeOffset.FromUnixTimeMilliseconds(0).Ticks
        internal static long ToUnixTimeNanoseconds(this DateTime dt)
        {
            return (dt.Ticks - UnixEpochTicks) * NanosecondsPerTicks;
        }

        internal static FusionOperateLog ToFusionOperateLog(this LogRecord log, Resource resource)
        {
            var resourceList = new List<KeyValuePair<string, string>>();
            var attributeList = new List<KeyValuePair<string, string>>();

            if (resource != Resource.Empty)
            {
                foreach (var resourceAttribute in resource.Attributes)
                {
                    resourceList.Add(new KeyValuePair<string, string>(resourceAttribute.Key, resourceAttribute.Value.ToString()));
                }
            }

            return new FusionOperateLog(
                timestamp: log.Timestamp.ToUnixTimeNanoseconds(),
                traceId: log.TraceId.ToHexString(),
                spanId: log.SpanId.ToHexString(),
                flags: (byte)log.TraceFlags,
                severityText: log.LogLevel.ToString(),
                severityNumber: (byte)log.LogLevel,
                name : log.CategoryName,
                body: log.FormattedMessage,
                resource: resourceList,
                attributes: attributeList
            );
        }
    }
}
